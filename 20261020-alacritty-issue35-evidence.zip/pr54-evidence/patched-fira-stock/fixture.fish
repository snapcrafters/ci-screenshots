printf '\e[2J\e[H'
printf '%s\n' 'PR #54 - commit e0c9680 (locally built snap)' 'Ubuntu 24.04.5 | GNOME/Wayland | 2 vCPU, 2 GiB VM' 'Fira Code 12 - reporter configuration | stock font rules'
printf '\nNo hand-written emoji rule. Same fixture and installed fonts.\n\n'
printf '%s\n' "Reporter test: printf '\\U0001F62D\\n'"
printf 'Crying U+1F62D:  [ '
printf '\U0001F62D'
printf ' ]\n'
sleep 1
printf '\nAdditional glyphs:  Crab [ 🦀 ]  Grinning [ 😀 ]  Thumbs up [ 👍 ]\n'
printf 'Mixed sequence:    🙈 😀 🤖 🐍 🏠 🚀 ✅ ❤️\n'
printf '\nASCII regular:  The quick brown fox 0123456789\n'
printf '\e[1mASCII bold:     The quick brown fox 0123456789\e[0m\n'
printf '\e[3mASCII italic:   The quick brown fox 0123456789\e[0m\n'
printf '\nCell grid: |0000000000|1111111111|2222222222|3333333333|\n'
printf '           |..........|..........|..........|..........|\n'
printf '\nFont choices and loaded libraries captured in accompanying logs.\n'
touch /home/ubuntu/pr54-evidence/patched-fira-stock/ready
sleep 180

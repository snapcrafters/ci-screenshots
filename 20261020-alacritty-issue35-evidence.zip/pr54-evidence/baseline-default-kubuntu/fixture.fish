printf '\e[2J\e[H'
printf '%s\n' 'BASELINE - Store revision 179 (local x1)' 'Ubuntu 24.04.5 | GNOME/Wayland | 2 vCPU, 2 GiB VM' 'Default monospace - no Alacritty configuration | kubuntu font rules'
printf '\nNo hand-written emoji rule. Same fixture and installed fonts.\n\n'
printf '%s\n' "Reporter test: printf '\\U0001F62D\\n'"
printf 'Crying U+1F62D:  [ '
printf '\U0001F62D'
printf ' ]\n'
sleep 1
printf '\nAdditional glyphs:  Crab [ 🦀 ]  Grinning [ 😀 ]  Thumbs up [ 👍 ]\n'
printf 'Mixed sequence:    🙈 😀 🤖 🐍 🏠 🚀 ✅ ❤️\n'
printf '\nASCII regular:  The quick brown fox 0123456789\n'
printf '\e[1mASCII bold:     The quick brown fox 0123456789\e[0m\n'
printf '\e[3mASCII italic:   The quick brown fox 0123456789\e[0m\n'
printf '\nCell grid: |0000000000|1111111111|2222222222|3333333333|\n'
printf '           |..........|..........|..........|..........|\n'
printf '\nFont choices and loaded libraries captured in accompanying logs.\n'
touch /home/ubuntu/pr54-evidence/baseline-default-kubuntu/ready
sleep 180

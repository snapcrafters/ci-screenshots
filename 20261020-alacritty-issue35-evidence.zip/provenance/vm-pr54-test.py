import json
import os
from pathlib import Path
import pty
import select
import subprocess
import sys
import time

mode, font_case, profile = sys.argv[1:]
assert mode in ('baseline', 'patched', 'native')
assert font_case in ('fira', 'default')
assert profile in ('stock', 'kubuntu')
kubuntu_rule = Path('/etc/fonts/conf.d/56-kubuntu-noto.conf')
if profile == 'kubuntu':
    kubuntu_rule.write_bytes(Path('/root/56-kubuntu-noto.conf').read_bytes())
else:
    kubuntu_rule.unlink(missing_ok=True)
root = Path('/home/ubuntu/pr54-evidence') / (mode + '-' + font_case + '-' + profile)
root.mkdir(parents=True, exist_ok=True)
subprocess.run(['chown', '-R', 'ubuntu:ubuntu', str(root.parent)], check=True)
env = os.environ | dict(HOME='/home/ubuntu', USER='ubuntu', LOGNAME='ubuntu', XDG_RUNTIME_DIR='/run/user/1000', DBUS_SESSION_BUS_ADDRESS='unix:path=/run/user/1000/bus')
manager = subprocess.check_output(['runuser', '-u', 'ubuntu', '--', 'systemctl', '--user', 'show-environment'], env=env, text=True)
for line in manager.splitlines():
    if '=' in line:
        k, v = line.split('=', 1)
        env[k] = v
for k in ['FONTCONFIG_FILE', 'FONTCONFIG_PATH', 'LD_LIBRARY_PATH', 'LD_PRELOAD']:
    env.pop(k, None)
for args in [
    ['gsettings', 'set', 'org.gnome.desktop.session', 'idle-delay', '0'],
    ['gsettings', 'set', 'org.gnome.desktop.screensaver', 'lock-enabled', 'false'],
    ['gdbus', 'call', '--session', '--dest', 'org.gnome.ScreenSaver', '--object-path', '/org/gnome/ScreenSaver', '--method', 'org.gnome.ScreenSaver.SetActive', 'false'],
]:
    subprocess.run(['runuser', '-u', 'ubuntu', '--', *args], env=env, capture_output=True, check=True, timeout=20)
assert not Path('/home/ubuntu/.config/fontconfig/conf.d/99-emoji-test.conf').exists()
subprocess.run(['runuser', '-u', 'ubuntu', '--', 'systemctl', '--user', 'stop', 'gnome-initial-setup-first-login.service'], env=env, capture_output=True, check=False)
config = Path('/home/ubuntu/.config/alacritty/alacritty.toml')
config.parent.mkdir(parents=True, exist_ok=True)
if font_case == 'fira':
    config.write_text('''[font]
size = 12
normal = { family = "Fira Code", style = "Regular" }
bold = { family = "Fira Code", style = "Bold" }
italic = { family = "Fira Code", style = "Italic" }
[window]
padding = { x = 8, y = 8 }
dynamic_padding = true
decorations = "full"
blur = true
startup_mode = "Maximized"
[cursor]
style = { shape = "Block", blinking = "On" }
[scrolling]
history = 10000
[selection]
save_to_clipboard = false
[mouse]
hide_when_typing = true
[terminal]
shell = "fish"
''')
    (root / 'alacritty.toml').write_bytes(config.read_bytes())
else:
    config.unlink(missing_ok=True)
label = {'baseline': 'BASELINE - Store revision 179 (local x1)', 'patched': 'PR #54 - commit e0c9680 (locally built snap)', 'native': 'NATIVE CONTROL - independently built upstream v0.17.0'}[mode]
font_label = ('Fira Code 12 - reporter configuration' if font_case == 'fira' else 'Default monospace - no Alacritty configuration') + ' | ' + profile + ' font rules'
fixture = root / 'fixture.fish'
fixture.write_text('''printf '\\e[2J\\e[H'
printf '%s\\n' ''' + "'" + label + "' 'Ubuntu 24.04.5 | GNOME/Wayland | 2 vCPU, 2 GiB VM' '" + font_label + "'" + '''
printf '\\nNo hand-written emoji rule. Same fixture and installed fonts.\\n\\n'
printf '%s\\n' "Reporter test: printf '\\\\U0001F62D\\\\n'"
printf 'Crying U+1F62D:  [ '
printf '\\U0001F62D'
printf ' ]\\n'
sleep 1
printf '\\nAdditional glyphs:  Crab [ 🦀 ]  Grinning [ 😀 ]  Thumbs up [ 👍 ]\\n'
printf 'Mixed sequence:    🙈 😀 🤖 🐍 🏠 🚀 ✅ ❤️\\n'
printf '\\nASCII regular:  The quick brown fox 0123456789\\n'
printf '\\e[1mASCII bold:     The quick brown fox 0123456789\\e[0m\\n'
printf '\\e[3mASCII italic:   The quick brown fox 0123456789\\e[0m\\n'
printf '\\nCell grid: |0000000000|1111111111|2222222222|3333333333|\\n'
printf '           |..........|..........|..........|..........|\\n'
printf '\\nFont choices and loaded libraries captured in accompanying logs.\\n'
touch ''' + str(root / 'ready') + '''
sleep 180
''')
subprocess.run(['chmod', '644', str(fixture)], check=True)
(root / 'ready').unlink(missing_ok=True)
binary = '/home/ubuntu/alacritty-native/target/release/alacritty' if mode == 'native' else '/snap/bin/alacritty'
args = [binary, '-vvv', '--title', label, '-e', '/usr/bin/fish', str(fixture)]
(root / 'command.json').write_text(json.dumps(args, indent=2))
(root / 'session.json').write_text(json.dumps({k: env.get(k) for k in ['DISPLAY', 'WAYLAND_DISPLAY', 'XDG_SESSION_TYPE']}, indent=2))
(root / 'os-release.txt').write_text(Path('/etc/os-release').read_text())
(root / 'packages.txt').write_text(subprocess.check_output(['dpkg-query','-W','fonts-firacode','fonts-noto-color-emoji','fonts-noto-core','fonts-dejavu-core','fontconfig','fish'],text=True))
(root / 'snap-list.txt').write_text(subprocess.check_output(['snap','list','alacritty'],text=True))
master, slave = pty.openpty()
proc = subprocess.Popen(['runuser', '-u', 'ubuntu', '--', *args], env=env, stdin=subprocess.DEVNULL, stdout=slave, stderr=slave)
os.close(slave)
output = bytearray()
def drain(timeout=0.1):
    while select.select([master], [], [], timeout)[0]:
        try:
            data = os.read(master, 65536)
        except OSError:
            break
        if not data:
            break
        output.extend(data)
        timeout = 0
    (root / 'launch.log').write_bytes(output)
try:
    deadline = time.monotonic() + 60
    while time.monotonic() < deadline and proc.poll() is None:
        drain()
        if (root / 'ready').exists():
            break
    assert (root / 'ready').exists() and proc.poll() is None, output.decode(errors='replace')
    time.sleep(2)
    drain()
    pid = subprocess.check_output(['pgrep', '-u', '1000', '-x', 'alacritty'], text=True).splitlines()[-1]
    (root / 'maps.txt').write_text(Path('/proc/' + pid + '/maps').read_text())
    (root / 'exe.txt').write_text(os.readlink('/proc/' + pid + '/exe'))
    (root / 'environment.txt').write_text('\n'.join(sorted(x for x in Path('/proc/' + pid + '/environ').read_bytes().decode().split('\0') if x.startswith(('FONTCONFIG_', 'XDG_CONFIG_HOME=', 'XDG_DATA_HOME=')))))
    subprocess.run(['runuser', '-u', 'ubuntu', '--', 'gnome-screenshot', '-f', str(root / 'desktop.png')], env=env, check=True, timeout=30)
    assert (root / 'desktop.png').stat().st_size > 1000
    print('CAPTURED', mode, font_case, root)
    for line in output.decode(errors='replace').splitlines():
        if any(k in line for k in ['Got font path', 'Cell size:', 'Version ', 'Running on ', 'OpenGL version', 'ERROR', 'WARN']):
            print(line)
finally:
    subprocess.run(['pkill', '-u', '1000', '-x', 'alacritty'], check=False)
    try:
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        proc.kill()
    drain()
    os.close(master)
